//
//  main.c
//  Copyright (c) 2013 Tauran Wood
//  
//  Copying and distribution of this file, with or without modification, is permitted in any medium without royalty provided the copyright notice and this notice are preserved.
//  This file is offered as-is,without warranty of any kind.
//
//  Created by Tauran Wood on 2013-01-30.
//
// mdtime version 2.0.2
//

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>

int main(int argc, char *argv[] )
{
	
	int lon = 0;
	int zone=0;
	int input;
	int hour=0;
	int min=0;
	int hdig=0;
	int digit;
	float sec;
	if (argc>1){
		if (strncmp(argv[1],"-l",2)==0){
			if (argc>2){
				lon = atoi(argv[2]);
			}
			else {
				printf("Longitude:\n");
				scanf("%i", &lon);
			}
			if (lon>180||lon<-180){
					printf("Longitude input is not a valid number");
					return 1;
			}
			else {
				lon-=114;
				zone=((lon/36)*100)+300;
			}
		}
		else if (strncmp(argv[1], "-c", 2)==0){
			if (argc>2){
				input = atoi(argv[2]);
				if (argc>3){
					min = atoi(argv[3]);
				}
			}
			else {
				printf("Hour:\n");
				scanf("%i", &input);
			}
			digit=input;
			while (digit>0) {
				digit=digit/10;
				hdig+=1;
			}
			if (hdig>4) {
				printf("Input too long\n");
				return 1;
			}
			else if (hdig>2) {
				if (argc>3) {
					printf("Too many inputs\n");
					return 1;
				}
				hour=input/100;
				min=input-(hour*100);
			}
			else {
				hour=input;
			}
			if (hour>24||min>60) {
				printf("Invalid time\n");
				return 1;
			}
			sec=((min+(hour*60))*60)/0.864;
			sec/=100;
			printf("%.2f\n",sec);
			return 0;
		}
		else if (strncmp(argv[1], "-r", 2)==0) {
			if (argc>2){
				sec = atoi(argv[2]);
			}
			else {
				printf("Time:\n");
				scanf("%f", &sec);
			}
			sec*=100*0.864;
			while (sec>((60*60)-1)){
				sec-=(60*60);
				hour+=1;
			}
			while (sec>(60-1)) {
				sec-=60;
				min+=1;
			}
			printf("%i:%02i\n",hour,min);
			return 0;
		}
		else if (strncmp(argv[1], "-z", 2)==0) {
			if (argc>2){
				input = atoi(argv[2]);
			}
			else {
				printf("Zone:");
				scanf("%i",&input);
			}
			digit=input;
			while (digit>0) {
				digit=digit/10;
				hdig+=1;
			}
			if (hdig==3) {
				zone=input;
			}
			else if (hdig==1){
				zone=input*100;
			}
		}
		else {
			printf("Invalid argument\n");
			return 1;
		}
	}
	else {
		zone=0;
	}
	zone -= 300;
	while (zone>=500) {
		zone-=1000;
	}
	while (zone<=500) {
		zone+=1000;
	}
	while (1){
		system("clear");
		int day=1;
		int ye=1970;
		int ns;
		long ep;
		float milli;
		float dyo;
		struct timeval here;
		time_t now;
		time(&now);
		gettimeofday(&here, 0);
		ep=here.tv_sec;
		ns=here.tv_usec;
		while (ep>=31622400) {
			ep-=31536000;
			ye++;
			if (ye%4==0&&(ye%100!=0||ye%400==0)) {
				ep-=86400;
			}
		}
		
		while (ep>86400) {
			ep-=86400;
			day++;
		}
		day--;
		ep*=1000000;
		ep+=ns;
		ep/=100000;
		milli=ep;
		milli=milli/864;
		milli+=50;
		milli+=zone;
		while (milli>1000){
			milli-=1000;
			day+=1;
		}
		while (milli<0){
			milli+=1000;
			day-=1;
		}
		ep=day/5;
		dyo=day%5;
		if (dyo==0) {
			dyo=5;
			ep-=1;
		}
		printf("%.2f\n", milli);
		printf("%ld / %.0f\n",ep, dyo);
		usleep(432000);
	}
	return 0;
}