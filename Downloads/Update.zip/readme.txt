1. Place wget.exe into C://WINDOWS
2. Edit the .bat file (right-click -> edit)
3. on the third line ou will find "wget http://assets.minecraft.net/XXXXX/minecraft.jar"
4. Replace XXXXX with the version you wish to download (note: any "."'s in the
version number should be replaced with "_"'s, ie. "1_4_4" or "12w50a")
5. run the .bat (doubleclick)
6. Yay!