//
//  mdtime.h
//
//  Created by Tauran Wood on 2013-04-29.
//  Copyright (c) 2013 Tauran Wood. All rights reserved.
//
#include <sys/time.h>
#include <string.h>

// zone: applies to all getmd functions
//	timezone:
//	can be input as eg. -4 or eg. -400
//	zone 0 is centered on Calgary
//	there are 10 zones (-500/-5 to 500/5)

// getmdTime: returns current time

float getmdTime(int zone) {
	if ((zone<100)&&(zone>-100)) zone=zone*100;
	zone-=300;
	int year=1970;
	int nanoSeconds;
	long milliSeconds;
	float timeOutput;
	struct timeval here;
	gettimeofday(&here, 0);
	milliSeconds=here.tv_sec;
	nanoSeconds=here.tv_usec;
	while (milliSeconds>=31622400) {
		milliSeconds-=31536000;
		year++;
		if (year%4==0&&(year%100!=0||year%400==0)) {
			milliSeconds-=86400;
		}
	}
	milliSeconds=milliSeconds%86400;
	milliSeconds*=1000000;
	milliSeconds+=nanoSeconds;
	milliSeconds/=100000;
	timeOutput=milliSeconds;
	timeOutput/=864;
	timeOutput+=50;
	timeOutput+=zone;
	while (timeOutput>1000){
		timeOutput-=1000;
	}
	while (timeOutput<0){
		timeOutput+=1000;
	}
	return timeOutput;
}

// getmdDate: returns date (decimal format)

float getmdDate(int zone) {
	if ((zone<100)&&(zone>-100)) zone=zone*100;
	zone-=300;
	int ordinalDay=1;
	int year=1970;
	int nanoSeconds;
	long milliSeconds;
	float output;
	struct timeval here;
	gettimeofday(&here, 0);
	milliSeconds=here.tv_sec;
	nanoSeconds=here.tv_usec;
	while (milliSeconds>=31622400) {
		milliSeconds-=31536000;
		year++;
		if (year%4==0&&(year%100!=0||year%400==0)) {
			milliSeconds-=86400;
		}
	}
	
	while (milliSeconds>86400) {
		milliSeconds-=86400;
		ordinalDay++;
	}
	milliSeconds*=1000000;
	milliSeconds+=nanoSeconds;
	milliSeconds/=100000;
	milliSeconds/=864;
	milliSeconds+=50;
	milliSeconds+=zone;
	while (milliSeconds>1000){
		milliSeconds-=1000;
		ordinalDay+=1;
	}
	while (milliSeconds<0){
		milliSeconds+=1000;
		ordinalDay-=1;
	}
	output=ordinalDay;
	return output/5;
}



// mdtostd: converts millidays to standard time
//  return of -1: input is not valid (ie. abov 1000 or below 0)

int mdtostd(float input){
	int hour=0;
	int min=0;
	if (input>1000||input<0) {
		return -1;
	}
	input*=100*0.864;
	while (input>((60*60)-1)){
		input-=(60*60);
		hour+=1;
	}
	while (input>(60-1)) {
		input-=60;
		min+=1;
	}
	return hour*100+min;
}

// stdtomd: converts standard time to millidays
// unit precision
//  input in 24h format eg. 1:07 PM --> 1307
//  no colon
// return of -1: input has too many digits (max 4)
// return of -2: input time is not valid (ie. 3700)

int stdtomd(int input) {
	int inputDigits=0;
	int digitCounter=input;
	int hour;
	int min;
	int sec;
	while (digitCounter>0) {
		digitCounter=digitCounter/10;
		inputDigits+=1;
	}
	if (inputDigits>4) {
		return -1;
	}
	else {
		hour=input/100;
		min=input-(hour*100);
	}
	if (hour>24||min>60) {
		return -2;
	}
	sec=((min+(hour*60))*60)/0.864;
	sec/=100;
	return sec;
}

// stdDateConv: converts date from standard format
//  returns date as a decimal, ie. 12.6 = 12/3, 24.8 = 24/4 etc.
//  returns negative values on faliure, -1: bad year, -2: bad month, -3 bad day
//  also takes ordinal date as input, just give month as 0 and day as ordinal date
//  returns 0 on leap day

float stdDateConv(int year, int month, int day) {
	if (month>1) {
		day+=31;
	}
	if (month>2) {
		if (year%4==0&&(year%100!=0||year%400==0)) {
			day+=29;
		}
		else {
			day+=28;
		}
	}
	if (month>3) {
		day+=31;
	}
	if (month>4) {
		day+=30;
	}
	if (month>5) {
		day+=31;
	}
	if (month>6) {
		day+=30;
	}
	if (month>7) {
		day+=31;
	}
	if (month>8) {
		day+=31;
	}
	if (month>9) {
		day+=30;
	}
	if (month>10) {
		day+=31;
	}
	if (month>11) {
		day+=30;
	}
	if (month>12||day>366) {
		return -2;
	}
	if (day==366&&(year%4==0&&(year%100!=0||year%400==0))) {
		return 0;
	}
	else {
		float output=day;
		return output/5;
	}
}

