
//  Copyright (c) 2013 Tauran Wood
//  
//  Copying and distribution of this file, with or without modification, is permitted in any medium without royalty provided the copyright notice and this notice are preserved.
//  This file is offered as-is,without warranty of any kind.
//
//  Created by Tauran Wood on 2013-01-30.
//
// mdtime version 3.0.0
//

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <unistd.h>
#include <string.h>
#include <sys/time.h>
#include "mdtime.h"

int main(int argc, char *argv[] )
{
	char* version = "3.0.0";
	int lon = 0;
	int zone=0;
	int input;
	int hour=0;
	int min=0;
	int hdig=0;
	int digit;
	if (argc>1){
		if (strncmp(argv[1],"-l",2)==0){
			if (argc>2){
				lon = atoi(argv[2]);
			}
			else {
				printf("Longitude:\n");
				scanf("%i", &lon);
			}
			if (lon>180||lon<-180){
					printf("Longitude input is not a valid number");
					return 1;
			}
			else {
				zone=((lon/36)*100)-300;
			}
		}
		else if (strncmp(argv[1], "-c", 2)==0){
			if (argc>2){
				input = atoi(argv[2]);
				if (argc>3){
					printf("Too Many Inputs");
					return 1;
				}
			}
			else {
				printf("Time:\n");
				scanf("%i", &input);
			}
			if (stdtomd(input)<0) {
				printf("Input not valid");
				return 1;
			}
			printf("%i\n",stdtomd(input));
			return 0;
		}
		else if (strncmp(argv[1], "-r", 2)==0) {
			if (argc>2){
				hour=mdtostd(atof(argv[2]));
			}
			else {
				float input;
				printf("Time:\n");
				scanf("%f", &input);
				hour=mdtostd(input);
			}
			if (hour==-1) {
				printf("Invalid input");
				return 1;
			}
			min=hour;
			hour/=100;
			min-=(hour*100);
			printf("%i:%i\n",hour,min);
			return 0;
		}
		else if (strncmp(argv[1], "-z", 2)==0) {
			if (argc>2){
				input = atoi(argv[2]);
			}
			else {
				printf("Zone:");
				scanf("%i",&input);
			}
			digit=input;
			while (digit>0) {
				digit=digit/10;
				hdig+=1;
			}
			if (hdig==3) {
				zone=input;
			}
			else if (hdig==1){
				zone=input*100;
			}
		}
		else if (strncmp(argv[1], "-v", 2)==0) {
			printf("%s\n",version);
			return 0;
		}
		else {
			printf("Invalid argument\n");
			return 1;
		}
	}
	else {
		zone=0;
	}
	while (zone>=500) {
		zone-=1000;
	}
	while (zone<=-500) {
		zone+=1000;
	}
	while (1){
		system("clear");
		float dateReturn=getmdDate(zone);
		int date1=floorf(dateReturn);
		int date2=round((dateReturn-date1)*5);
		if (date2==0) {
			date1-=1;
			date2=5;
		}
		printf("%.2f\n", getmdTime(zone));
		printf("%i / %i\n",date1, date2);
		usleep(432000);
	}
	return 0;
}
